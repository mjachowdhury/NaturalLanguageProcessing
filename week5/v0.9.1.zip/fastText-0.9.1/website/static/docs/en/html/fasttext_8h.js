var fasttext_8h =
[
    [ "FastText", "classfasttext_1_1FastText.html", "classfasttext_1_1FastText" ],
    [ "FASTTEXT_FILEFORMAT_MAGIC_INT32", "fasttext_8h.html#af5de14588083ef853a2863c8d625ee24", null ],
    [ "FASTTEXT_VERSION", "fasttext_8h.html#a74036bd705019bb33643e90202bf343e", null ]
];