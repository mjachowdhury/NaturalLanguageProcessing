var classfasttext_1_1QMatrix =
[
    [ "QMatrix", "classfasttext_1_1QMatrix.html#a976442aaed5b1afee2f2cd4473c0d62b", null ],
    [ "QMatrix", "classfasttext_1_1QMatrix.html#ae10f3f12bf4c8483381ecb122b7fda5a", null ],
    [ "~QMatrix", "classfasttext_1_1QMatrix.html#a7de6d212bec1c4028ee30e968b5d030d", null ],
    [ "addToVector", "classfasttext_1_1QMatrix.html#ad8f153a45f69530aeef171bebbce93fc", null ],
    [ "dotRow", "classfasttext_1_1QMatrix.html#ad1671bceb60d87492b662331cc084c56", null ],
    [ "getM", "classfasttext_1_1QMatrix.html#a16350455c02cf5f00175b1b0c6a310cd", null ],
    [ "getN", "classfasttext_1_1QMatrix.html#ad969042dfc46a64e386f12616a4d6bcb", null ],
    [ "load", "classfasttext_1_1QMatrix.html#a03c039b81b5aaed30d95149de9379998", null ],
    [ "quantize", "classfasttext_1_1QMatrix.html#ab9ae1914dc1b72e305880a8c22626afc", null ],
    [ "quantizeNorm", "classfasttext_1_1QMatrix.html#a0e4d84be1c6cd0cbfc4568f905961017", null ],
    [ "save", "classfasttext_1_1QMatrix.html#a00267b43ee5eefc92948c654fb9fc9f1", null ],
    [ "codes_", "classfasttext_1_1QMatrix.html#acc957d3d66b58cb9381f6a0556096c93", null ],
    [ "codesize_", "classfasttext_1_1QMatrix.html#a4a69f60ba96c0b1a9da22c3951eca759", null ],
    [ "m_", "classfasttext_1_1QMatrix.html#ad2457490bb9a531740187fffb63cace2", null ],
    [ "n_", "classfasttext_1_1QMatrix.html#a54082c819b9939e2d49fc0733a609cea", null ],
    [ "norm_codes_", "classfasttext_1_1QMatrix.html#a17f22153d042c64052a3468faec70fce", null ],
    [ "npq_", "classfasttext_1_1QMatrix.html#a8203216a4cb2b721697f7dc2b509f25a", null ],
    [ "pq_", "classfasttext_1_1QMatrix.html#a6c62644a138ed88863088dcdeb32dbd7", null ],
    [ "qnorm_", "classfasttext_1_1QMatrix.html#aadc6e4d399442555f3c2993b97285143", null ]
];