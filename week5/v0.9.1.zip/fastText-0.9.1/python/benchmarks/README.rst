These programs allow us to compare the performance of a few key operations when consindering changes. 

It is important to run these to make sure a change doesn't introduce a regression.
